#ifndef _Queue_h
#define _Queue_h

/*
    Queue.h
        
    class definition for the Queue class.

    assignment: CSCI 262 Lab 9 - queue2        

    author: 

    last modified: 3/15/2018
*/

class Queue {
public:
	// max elements in queue
	static const size_t ARRAY_SZ = 5;

    // constructor
	Queue() { _front = 0; _back = 0; _size = 0; }

    // enqueue: add a char to the end of the queue if room and return true;
    // if not enough room, return false
	bool enqueue(char c) {
        if (_size == ARRAY_SZ) return false;
		_data[_back] = c;
		_back = (_back + 1) % ARRAY_SZ;
        _size++;
		return true;
	}
		
    // dequeue: if queue is not empty, remove the front element from the queue;
    // if queue is empty, return false and do nothing.
	bool dequeue()  { 
		if (is_empty()) { return false; }
		_front = (_front + 1) % ARRAY_SZ; 
        _size--;
		return true;
	}

    // front: return the front element in the queue
	char front()    { return _data[_front]; }

    // is_empty: return whether or not the queue is empty
	bool is_empty() { return _size == 0; }

private:
	char _data[ARRAY_SZ];
    int  _size;
	int  _front;
	int  _back;
	
};

#endif
